long double add(long double a, long double b)
{
	return (a + b);
}