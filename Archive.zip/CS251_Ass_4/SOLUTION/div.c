long double div(long double a,long double b)
{
	return (a/b);
}