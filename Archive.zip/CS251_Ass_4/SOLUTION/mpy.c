long double mpy(long double a,long double b)
{
	return (a * b);
}