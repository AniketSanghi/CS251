//Declaring functions
long double add(long double,long double);
long double sub(long double,long double);
long double mpy(long double,long double);
long double div(long double,long double);